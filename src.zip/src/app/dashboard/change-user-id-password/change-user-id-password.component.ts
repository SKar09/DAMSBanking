import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-user-id-password',
  templateUrl: './change-user-id-password.component.html',
  styleUrls: ['./change-user-id-password.component.css']
})
export class ChangeUserIdPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
