import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-successful',
  templateUrl: './transfer-successful.component.html',
  styleUrls: ['./transfer-successful.component.css']
})
export class TransferSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
