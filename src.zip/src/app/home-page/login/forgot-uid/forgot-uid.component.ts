import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-uid',
  templateUrl: './forgot-uid.component.html',
  styleUrls: ['./forgot-uid.component.css']
})
export class ForgotUIDComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
